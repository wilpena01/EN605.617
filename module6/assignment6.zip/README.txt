This is an explanation about the report of assignment 4.

There should be 11 files here:
	README.txt
	assignment.cu
	Makefile
	ADD.h
	SUB.h
	MUL.h
	MOD.h
	Utilities.h
	latestOutput.txt
	InputSizeVSTime.xslx
	Stretchproblem.txt
	
	

README.txt:
The explanation of all the documentation (This file).


assignment.cu:
is the main cuda file.


Makefile:
This is the make file used to create the assignment.exe and Caesar_cypher.exe.


ADD.h:
Is the file responsible for the preparation of the addition module and running
in the kernel.


SUB.h:
Is the file responsible for the preparation of the subtraction module and running
in the kernel.


MUL.h:
Is the file responsible for the preparation of the multiplication module and running
in the kernel.


MOD.h:
Is the file responsible for the preparation of the modulo module and running
in the kernel.


Utilities.h:
This file is contain a lot of functions that are needed in the program.


latestOutput.txt:
it has the latest output from the main cuda file.



InputSizeVSTime.xslx:
This file shows the difference in execution time between Input size and local memory allocation.


Stretchproblem.txt:
Say some of the good and bad things the stretch problem have.


